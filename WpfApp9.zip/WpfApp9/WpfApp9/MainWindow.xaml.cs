﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp9
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Lottoszamok(int db, int hatar)
        {
            Random vsz = new Random();
            int szam;
            int i = 1;
            while (i < db)
            {
                szam = vsz.Next(1, hatar + 1);
                if (!szamoklista.Items.Contains(szam))
                    {
                        szamoklista.Items.Add(szam);
                        i++;
                    }
            }
        }

        private void general_Click(object sender, RoutedEventArgs e)
        {
            szamoklista.Items.Clear();
            if (otoslotto.IsChecked == true) 
            {
                Lottoszamok(5, 90);
            }
            if (hatoslotto.IsChecked == true) 
            {
                Lottoszamok(6, 45);
            }
            if (skandinavlotto.IsChecked == true) 
            {
                Lottoszamok(7, 35);
            }
        }

        private void fajlabir_Click(object sender, RoutedEventArgs e)
        {

        }

        private void fajlbololvas_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}