﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp10
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void dobasok_Click(object sender, RoutedEventArgs e)
        {
            elsolista.Items.Clear();
            masodiklista.Items.Clear();
            Random vsz = new Random();

            for(int i = 1; i <= 10; i++)
            {
                elsolista.Items.Add(vsz.Next(1,7));
                masodiklista.Items.Add(vsz.Next(1,7));
            }
        }

        private void ertekel_Click(object sender, RoutedEventArgs e)
        {
            double elsoatlag = 0;
            double masodikatlag = 0;
            int hatosdb1 = 0;
            int hatosdb2 = 0;   
            for (int i = 0; i < elsolista.Items.Count; i++)
            {
                elsoatlag += Convert.ToDouble((elsolista.Items[i]));
                if (Convert.ToDouble(elsolista.Items[i]) == 6)
                {
                    hatosdb1++;
                }
            }
            for (int i = 0; i < masodiklista.Items.Count; i++)
            {
                masodikatlag += Convert.ToDouble(masodiklista.Items[i]);
                if (Convert.ToDouble(masodiklista.Items[i]) == 6)
                {
                    hatosdb2++;
                }
            }
            elsoatlag /= 10;
            masodikatlag /= 10;
            if(hatosdb1 > hatosdb2)
            {
                nyertes.Text = "Első játékos";
            }
            else if(hatosdb2 > hatosdb1)
            {
                nyertes.Text = "Második játékos";
            }
            else
            {
                nyertes.Text = "Döntetlen!";
            }
            elsoatl.Text = elsoatlag.ToString();
            masodikatl.Text = masodikatlag.ToString();
        }
    }
}